package pessoa;

public class Principal {
    
    public static void main(String[] args) {
        
        Pessoa pessoa1 = new Pessoa();
        
        pessoa1.cadastroPessoa1();
        pessoa1.imprimir();
        
        pessoa1.cadastroPessoa2();
        pessoa1.imprimir();
        
        pessoa1.cadastroPessoa3();
        pessoa1.imprimir();
        
        /*
        pessoa1.setNome("Rafael");
        pessoa1.setIdade(38);
        pessoa1.setPeso(110);
        pessoa1.setTelefone("8401-4320");
        */
                
        /*String nome, telefone;
        int idade;
        float peso;
        
        nome = "Rafael";
        idade = 38;
        peso = 100;
        telefone = "8401-4320";
        
        pessoa1.setNome(nome);
        pessoa1.setIdade(idade);
        pessoa1.setPeso(peso);
        pessoa1.setTelefone(telefone);*/
        
        /*
        System.out.println("Nome: "+pessoa1.getNome());
        System.out.println("Idade: "+pessoa1.getIdade());
        System.out.println("Peso: "+pessoa1.getPeso());
        System.out.println("Telefone: "+pessoa1.getTelefone());
        */               
    }
}
