
package pessoa;

import java.util.Scanner;


public class Pessoa {
    public String nome;
    public String telefone;
    public int idade;
    public float peso;

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return this.telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getIdade() {
        return this.idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public float getPeso() {
        return this.peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }
    
    public void cadastroPessoa1(){
        this.setNome("Rafael");
        this.setIdade(38);
        this.setPeso(110);
        this.setTelefone("8401-4320");
    }
    
    public void cadastroPessoa2(){
        String nome, telefone;
        int idade;
        float peso;
        
        nome = "Rafael";
        idade = 38;
        peso = 100;
        telefone = "8401-4320";
        
        this.setNome(nome);
        this.setIdade(idade);
        this.setPeso(peso);
        this.setTelefone(telefone);
    }
    
    public void cadastroPessoa3(){
        Scanner cad = new Scanner(System.in);
        System.out.println(".............................");
        
        System.out.println("Nome.....: ");
        String nome = cad.nextLine();
        this.setNome(nome);
        
        System.out.println("Idade....: ");
        int idade = cad.nextInt();
        this.setIdade(idade);
        
        System.out.println("Peso.....: ");
        float peso = cad.nextFloat();
        this.setPeso(peso);
        cad.nextLine();
     
        System.out.println("Telefone.: ");
        String telefone = cad.nextLine();
        this.setTelefone(telefone); 
    }
    
    public void imprimir(){
        System.out.println(".............................");
        System.out.println("Nome.....: "+this.getNome());
        System.out.println("Idade....: "+this.getIdade());
        System.out.println("Peso.....: "+this.getPeso());
        System.out.println("Telefone.: "+this.getTelefone());
        System.out.println(".............................");
    }
}