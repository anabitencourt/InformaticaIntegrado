
package projetorafael;

/**
 *
 * @author programacao1
 */
public class ProjetoRafael {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int valor1;
        valor1 = 10;
        
        System.out.println("Valor  da variável = "+valor1);
        
        int a = 45;
        int b = 45;
        int c = a + b;
        System.out.println(
                "A soma da variável A(" +a+ ") "
                + "com B(" +b+ ") = "+ c);
        
        String nome;
        nome = "Rafael";
        System.out.println("variáve nome = " + nome);
        
        double salario;
        salario = 2598.67;
        System.out.println("Salário R$ " + salario);
        
        int i;
        for(i = 0; i < 10; i++)
        {
            System.out.print("Número " + i + " = ");
            if (i % 2 == 0)
            {
                System.out.print("Par");
            }else
            {
                System.out.print("Impar");
            }
            System.out.println("");
        }
        i = 0;
        while( i < 10)
        {
            System.out.print("Número " + i + " = ");
            if (i % 2 == 0)
            {
                System.out.print("Par");
            }else
            {
                System.out.print("Impar");
            }
            System.out.println("");
            i++;
        }
    }
    
}
